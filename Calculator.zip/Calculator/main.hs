{-# LANGUAGE OverloadedStrings     #-}
{-# LANGUAGE QuasiQuotes           #-}
{-# LANGUAGE TemplateHaskell       #-}
{-# LANGUAGE TypeFamilies          #-}
import           Yesod
import   Prelude (IO, Double)
import           Data.Text (Text, unpack)
import           Text.Hamlet (shamlet)
import           Text.Shakespeare.Text (stext)
import           ClassyPrelude
import           GHC.Generics
import           Data.Aeson

data App = App

mkYesod "App" [parseRoutes|
/               HomeR GET
/add/#Int/#Int  AddR GET
/sub/#Int/#Int  SubR GET
/mul/#Int/#Int  MulR GET
/div/#Int/#Int  DivR GET
|]

instance Yesod App

getHomeR :: Handler TypedContent
getHomeR = selectRep $ do
    provideRep $ defaultLayout $ do
       [whamlet|Welcome to my Calculator|]

getAddR :: Int -> Int -> Handler TypedContent
getAddR x y = selectRep $ do
    provideRep $ defaultLayout $ do
        setTitle "Addition"
        [whamlet|The Result is #{res}|]
    provideJson res
  where
    res = x + y


getSubR :: Int -> Int -> Handler TypedContent
getSubR x y = selectRep $ do
    provideRep $ defaultLayout $ do
        setTitle "Subtraction"
        [whamlet|The Result is #{res}|]
    provideJson res
  where
    res = x - y


getMulR :: Int -> Int -> Handler TypedContent
getMulR x y = selectRep $ do
    provideRep $ defaultLayout $ do
        setTitle "Multiplication"
        [whamlet|The Result is #{res}|]
    provideJson res
  where
    res = x * y


getDivR :: Int -> Int -> Handler TypedContent
getDivR x y = selectRep $ do
    provideRep $ defaultLayout $ do
        setTitle "Division"
        [whamlet|The Result is #{res}|]
    provideJson res
  where
    res = divideN x y

divideN :: Int -> Int -> Double
divideN x y = (fromIntegral x) / (fromIntegral y)


main :: IO ()
main = warp 3000 App
